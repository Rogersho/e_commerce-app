package com.example.ecommerce_poco

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
